function jsTest()
{
	alert("Hey, javascript works!!!");
}